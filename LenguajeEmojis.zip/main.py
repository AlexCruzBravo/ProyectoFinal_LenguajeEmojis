from antlr4 import *
from rulesLexer import rulesLexer
from rulesParser import rulesParser
from listenerRules import ListenerRules
import os

def main():
    while True:
        in_file = input("\nIngrese el nombre del archivo: ").strip()
        
        # Validar que se ingresó algo
        if not in_file:
            print("Error: Debe ingresar un nombre de archivo")
            continue
            
        # Validar que el archivo existe
        if not os.path.exists(in_file):
            print(f"Error: El archivo '{in_file}' no existe")
            continue
            
        break
    
    # Obtener el nombre base del archivo sin extensión
    base_name = os.path.splitext(in_file)[0]
    output_file = f"{base_name}.py"
    
    with open(in_file, 'r', encoding='utf-8', errors='ignore') as file:
        contenido = file.read()
        
        input_stream = InputStream(contenido)
        lexer = rulesLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = rulesParser(stream)
        tree = parser.programa()

        listener = ListenerRules(output_file)  # Pasamos el nombre del archivo de salida
        walker = ParseTreeWalker()
        walker.walk(listener, tree)

if __name__ == "__main__":
    main()

