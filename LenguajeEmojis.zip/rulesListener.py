# Generated from rules.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .rulesParser import rulesParser
else:
    from rulesParser import rulesParser

# This class defines a complete listener for a parse tree produced by rulesParser.
class rulesListener(ParseTreeListener):

    # Enter a parse tree produced by rulesParser#programa.
    def enterPrograma(self, ctx:rulesParser.ProgramaContext):
        pass

    # Exit a parse tree produced by rulesParser#programa.
    def exitPrograma(self, ctx:rulesParser.ProgramaContext):
        pass


    # Enter a parse tree produced by rulesParser#bloquePrograma.
    def enterBloquePrograma(self, ctx:rulesParser.BloqueProgramaContext):
        pass

    # Exit a parse tree produced by rulesParser#bloquePrograma.
    def exitBloquePrograma(self, ctx:rulesParser.BloqueProgramaContext):
        pass


    # Enter a parse tree produced by rulesParser#declaracion.
    def enterDeclaracion(self, ctx:rulesParser.DeclaracionContext):
        pass

    # Exit a parse tree produced by rulesParser#declaracion.
    def exitDeclaracion(self, ctx:rulesParser.DeclaracionContext):
        pass


    # Enter a parse tree produced by rulesParser#condicion.
    def enterCondicion(self, ctx:rulesParser.CondicionContext):
        pass

    # Exit a parse tree produced by rulesParser#condicion.
    def exitCondicion(self, ctx:rulesParser.CondicionContext):
        pass


    # Enter a parse tree produced by rulesParser#bloqueCondicion.
    def enterBloqueCondicion(self, ctx:rulesParser.BloqueCondicionContext):
        pass

    # Exit a parse tree produced by rulesParser#bloqueCondicion.
    def exitBloqueCondicion(self, ctx:rulesParser.BloqueCondicionContext):
        pass


    # Enter a parse tree produced by rulesParser#ciclo.
    def enterCiclo(self, ctx:rulesParser.CicloContext):
        pass

    # Exit a parse tree produced by rulesParser#ciclo.
    def exitCiclo(self, ctx:rulesParser.CicloContext):
        pass


    # Enter a parse tree produced by rulesParser#bloqueCiclo.
    def enterBloqueCiclo(self, ctx:rulesParser.BloqueCicloContext):
        pass

    # Exit a parse tree produced by rulesParser#bloqueCiclo.
    def exitBloqueCiclo(self, ctx:rulesParser.BloqueCicloContext):
        pass


    # Enter a parse tree produced by rulesParser#funcion.
    def enterFuncion(self, ctx:rulesParser.FuncionContext):
        pass

    # Exit a parse tree produced by rulesParser#funcion.
    def exitFuncion(self, ctx:rulesParser.FuncionContext):
        pass


    # Enter a parse tree produced by rulesParser#bloqueFuncion.
    def enterBloqueFuncion(self, ctx:rulesParser.BloqueFuncionContext):
        pass

    # Exit a parse tree produced by rulesParser#bloqueFuncion.
    def exitBloqueFuncion(self, ctx:rulesParser.BloqueFuncionContext):
        pass


    # Enter a parse tree produced by rulesParser#llamadaFuncion.
    def enterLlamadaFuncion(self, ctx:rulesParser.LlamadaFuncionContext):
        pass

    # Exit a parse tree produced by rulesParser#llamadaFuncion.
    def exitLlamadaFuncion(self, ctx:rulesParser.LlamadaFuncionContext):
        pass


    # Enter a parse tree produced by rulesParser#imprimir.
    def enterImprimir(self, ctx:rulesParser.ImprimirContext):
        pass

    # Exit a parse tree produced by rulesParser#imprimir.
    def exitImprimir(self, ctx:rulesParser.ImprimirContext):
        pass


    # Enter a parse tree produced by rulesParser#entrada.
    def enterEntrada(self, ctx:rulesParser.EntradaContext):
        pass

    # Exit a parse tree produced by rulesParser#entrada.
    def exitEntrada(self, ctx:rulesParser.EntradaContext):
        pass


    # Enter a parse tree produced by rulesParser#parametros.
    def enterParametros(self, ctx:rulesParser.ParametrosContext):
        pass

    # Exit a parse tree produced by rulesParser#parametros.
    def exitParametros(self, ctx:rulesParser.ParametrosContext):
        pass


    # Enter a parse tree produced by rulesParser#argumentos.
    def enterArgumentos(self, ctx:rulesParser.ArgumentosContext):
        pass

    # Exit a parse tree produced by rulesParser#argumentos.
    def exitArgumentos(self, ctx:rulesParser.ArgumentosContext):
        pass


    # Enter a parse tree produced by rulesParser#condicionLogica.
    def enterCondicionLogica(self, ctx:rulesParser.CondicionLogicaContext):
        pass

    # Exit a parse tree produced by rulesParser#condicionLogica.
    def exitCondicionLogica(self, ctx:rulesParser.CondicionLogicaContext):
        pass


    # Enter a parse tree produced by rulesParser#bloque.
    def enterBloque(self, ctx:rulesParser.BloqueContext):
        pass

    # Exit a parse tree produced by rulesParser#bloque.
    def exitBloque(self, ctx:rulesParser.BloqueContext):
        pass


    # Enter a parse tree produced by rulesParser#expresion.
    def enterExpresion(self, ctx:rulesParser.ExpresionContext):
        pass

    # Exit a parse tree produced by rulesParser#expresion.
    def exitExpresion(self, ctx:rulesParser.ExpresionContext):
        pass


    # Enter a parse tree produced by rulesParser#termino.
    def enterTermino(self, ctx:rulesParser.TerminoContext):
        pass

    # Exit a parse tree produced by rulesParser#termino.
    def exitTermino(self, ctx:rulesParser.TerminoContext):
        pass


    # Enter a parse tree produced by rulesParser#tipoDato.
    def enterTipoDato(self, ctx:rulesParser.TipoDatoContext):
        pass

    # Exit a parse tree produced by rulesParser#tipoDato.
    def exitTipoDato(self, ctx:rulesParser.TipoDatoContext):
        pass


    # Enter a parse tree produced by rulesParser#asignacion.
    def enterAsignacion(self, ctx:rulesParser.AsignacionContext):
        pass

    # Exit a parse tree produced by rulesParser#asignacion.
    def exitAsignacion(self, ctx:rulesParser.AsignacionContext):
        pass


    # Enter a parse tree produced by rulesParser#incremento.
    def enterIncremento(self, ctx:rulesParser.IncrementoContext):
        pass

    # Exit a parse tree produced by rulesParser#incremento.
    def exitIncremento(self, ctx:rulesParser.IncrementoContext):
        pass


    # Enter a parse tree produced by rulesParser#operadorAritmetico.
    def enterOperadorAritmetico(self, ctx:rulesParser.OperadorAritmeticoContext):
        pass

    # Exit a parse tree produced by rulesParser#operadorAritmetico.
    def exitOperadorAritmetico(self, ctx:rulesParser.OperadorAritmeticoContext):
        pass


    # Enter a parse tree produced by rulesParser#operadorLogico.
    def enterOperadorLogico(self, ctx:rulesParser.OperadorLogicoContext):
        pass

    # Exit a parse tree produced by rulesParser#operadorLogico.
    def exitOperadorLogico(self, ctx:rulesParser.OperadorLogicoContext):
        pass


    # Enter a parse tree produced by rulesParser#inicio.
    def enterInicio(self, ctx:rulesParser.InicioContext):
        pass

    # Exit a parse tree produced by rulesParser#inicio.
    def exitInicio(self, ctx:rulesParser.InicioContext):
        pass


    # Enter a parse tree produced by rulesParser#fin.
    def enterFin(self, ctx:rulesParser.FinContext):
        pass

    # Exit a parse tree produced by rulesParser#fin.
    def exitFin(self, ctx:rulesParser.FinContext):
        pass



del rulesParser