def main():
	edad = 25 # entero
	nombre = "Juan" # cadena
	mensaje = None # valor nulo
	if edad>18:
		print("Eres mayor de edad.")
	else:
		print("Eres menor de edad.")
	else:

	for contador in range(0, 20):
		print("Contando: ",contador)
	if edad>18:
		print("Eres mayor de edad.")
	else:
		print("Eres menor de edad.")
	else:

def saludo(nombre):
		print("¡Hola, "+nombre+"!")
if __name__ == '__main__':
	main()
	saludo("Carlos")