from rulesListener import rulesListener
from rulesParser import rulesParser

class ListenerRules(rulesListener):
    def __init__(self, output_file):
        self.file = open(output_file, 'w', encoding='utf-8')
        self.llamadas_funciones = []
        super().__init__()

    def __del__(self):
        self.file.close()
    # Enter a parse tree produced by rulesParser#programa.
    def enterPrograma(self, ctx:rulesParser.ProgramaContext):
        print("def main():")
        self.file.write("def main():\n")
        pass

    # Exit a parse tree produced by rulesParser#programa.
    def exitPrograma(self, ctx:rulesParser.ProgramaContext):

        
        print("if __name__ == '__main__':\n    main()")
        self.file.write("if __name__ == '__main__':\n\tmain()")
        for llamada in self.llamadas_funciones:
            print(f"\n\t{llamada}")
            self.file.write(f"\n\t{llamada}")
        print(f"\n\n Programa terminado y generado en {self.file.name}")
        print("\n\n\n\n")
        pass

    # Enter a parse tree produced by rulesParser#declaracion.
    def enterDeclaracion(self, ctx:rulesParser.DeclaracionContext):
        tipo = ctx.tipoDato().getText()
        identificador = ctx.IDENTIFICADOR().getText()
        valor = ctx.expresion().getText()
        
        valor = valor.replace('➕', '+')
        valor = valor.replace('➖', '-')
        valor = valor.replace('✖️', '*')
        valor = valor.replace('➗', '/')

        if valor == "null":
            print(f"\t{identificador} = None # valor nulo")
            self.file.write(f"\t{identificador} = None # valor nulo\n")
        else:
            if tipo == '🔢':    
                print(f"\t{identificador} = {valor} # entero")
                self.file.write(f"\t{identificador} = {valor} # entero\n")
            elif tipo == '🔡':
                print(f"\t{identificador} = {valor} # cadena")
                self.file.write(f"\t{identificador} = {valor} # cadena\n")
            elif tipo == '🔣':
                print(f"\t{identificador} = {valor} # float")
                self.file.write(f"\t{identificador} = {valor} # float\n")
            elif tipo == '#️⃣':
                print(f"\t{identificador} = {valor} # boolean")
                self.file.write(f"\t{identificador} = {valor} # boolean\n")
            elif tipo == '🆓':
                print(f"\t{identificador} = None # null")
                self.file.write(f"\t{identificador} = None # null\n")
                
        pass

    # Enter a parse tree produced by rulesParser#condicion.
    def enterCondicion(self, ctx:rulesParser.CondicionContext):
        condicion = ctx.condicionLogica().getText()
        
        # Reemplazar operadores lógicos en emoji
        condicion = condicion.replace('▶️', '>')    # Mayor que
        condicion = condicion.replace('◀️', '<')    # Menor que
        condicion = condicion.replace('⏭️', '>=')   # Mayor o igual que
        condicion = condicion.replace('⏮️', '<=')   # Menor o igual que
        condicion = condicion.replace('⏯️', '==')   # Igual que
        condicion = condicion.replace('🔀', '!=')   # Diferente que
        condicion = condicion.replace('🔄', 'or')   # OR lógico
        
        
        print(f"\n\tif {condicion}:")
        self.file.write(f"\tif {condicion}:\n")

        pass
    
    def enterBloqueCondicion(self, ctx:rulesParser.BloqueCondicionContext):
        texto = ctx.getText()
        texto = texto.strip('{}')
        # Reemplazar emojis por sus equivalentes en instrucciones print
        texto = texto.replace('🖨️', 'print')
        texto = texto.replace('➡️', '>=')
        texto = texto.replace('⬅️', '<=')
        texto = texto.replace('▶️', '>')
        texto = texto.replace('◀️', '<')
        texto = texto.replace('⏯️', '==')
        texto = texto.replace('🔀', '!=')
        texto = texto.replace('🔄', 'or')
        texto = texto.replace('➕', '+')
        texto = texto.replace('➖', '-')
        texto = texto.replace('✖️', '*')
        texto = texto.replace('➗', '/')
        texto = texto.replace('⬆️', '**')
        
        # print(f"\t\t{texto}")
        #self.file.write(f"\t\t{texto}\n")
        pass

    # Exit a parse tree produced by rulesParser#bloqueCondicion.
    def exitBloqueCondicion(self, ctx:rulesParser.BloqueCondicionContext):
        print("\telse:")
        self.file.write("\telse:\n")
        pass

    # Enter a parse tree produced by rulesParser#ciclo.
    def enterCiclo(self, ctx:rulesParser.CicloContext):
        asignacion = ctx.asignacion().getText()
        condicion = ctx.condicionLogica().getText()
        
        # Obtener el valor inicial de la asignación
        valor_inicial = asignacion.split('=')[1]
        
        # Reemplazar operadores lógicos en emoji antes de procesar la condición
        condicion = condicion.replace('▶️', '>')
        condicion = condicion.replace('◀️', '<')
        condicion = condicion.replace('⏭️', '>=')
        condicion = condicion.replace('⏮️', '<=')
        condicion = condicion.replace('⏯️', '==')
        condicion = condicion.replace('🔀', '!=')
        
        # Validar y obtener el valor de la condición según el operador
        valor_condicion = None
        # Ordenar operadores por longitud descendente para manejar >= y <= correctamente
        operadores = sorted(['==', '>=', '<=', '>', '<', '!='], key=len, reverse=True)
        
        for operador in operadores:
            if operador in condicion:
                try:
                    partes = condicion.split(operador)
                    valor_condicion = partes[1].strip()
                    break
                except IndexError:
                    continue
        
        if valor_condicion is None:
            print("Error: No se encontró un operador válido en la condición")
            return
            
        # Asegurarse de que la variable de asignación esté limpia de espacios
        variable = asignacion.split('=')[0].strip()
        
        ciclo = f"\n\tfor {variable} in range({valor_inicial}, {valor_condicion}):\n"
        print(ciclo)
        self.file.write(ciclo)
        
        pass

    # Enter a parse tree produced by rulesParser#bloqueCiclo.
    def enterBloqueCiclo(self, ctx:rulesParser.BloqueCicloContext):
        texto = ctx.getText()
        texto = texto.strip('{}')
        # Reemplazar emojis por sus equivalentes en instrucciones print
        texto = texto.replace('🖨️', 'print')
        texto = texto.replace('⏭️', '>=')
        texto = texto.replace('⏮️', '<=')
        texto = texto.replace('▶️', '>')
        texto = texto.replace('◀️', '<')
        texto = texto.replace('⏯️', '==')
        texto = texto.replace('🔀', '!=')
        texto = texto.replace('🔄', 'for')
        texto = texto.replace('➕', '+')
        texto = texto.replace('➖', '-')
        texto = texto.replace('✖️', '*')
        texto = texto.replace('➗', '/')
        texto = texto.replace('⬆️', '**')
        texto = texto.replace('✅', 'True')
        texto = texto.replace('❌', 'False')
        texto = texto.replace('❓', 'if')
        texto = texto.replace('💡', 'else')
        texto = texto.replace('⚙️', 'def')
        texto = texto.replace('📥', 'input')
        texto = texto.replace('🔢', 'int')
        texto = texto.replace('🔡', 'str')
        texto = texto.replace('🔣', 'bool')
        texto = texto.replace('#️⃣', 'float')
        texto = texto.replace('🆓', 'None')
        texto = texto.replace('⏩', '+=')
        texto = texto.replace('⏪', '-=')
        texto = texto.replace('👉', ',')
        
        #print(f"\t\t{texto}")
        #self.file.write(f"\t\t{texto}\n")
        pass

    # Enter a parse tree produced by rulesParser#funcion.
    def enterFuncion(self, ctx:rulesParser.FuncionContext):
        print(f"\ndef {ctx.IDENTIFICADOR().getText()}({ctx.parametros().getText()}):")
        self.file.write(f"\ndef {ctx.IDENTIFICADOR().getText()}({ctx.parametros().getText()}):\n")
        pass

    # Enter a parse tree produced by rulesParser#bloqueFuncion.
    def enterBloqueFuncion(self, ctx:rulesParser.BloqueFuncionContext):
        texto = ctx.getText()
        texto = texto.strip('{}')
        # Reemplazar emojis por sus equivalentes en instrucciones print
        texto = texto.replace('🖨️', 'print')
        texto = texto.replace('⏭️', '>=')
        texto = texto.replace('⏮️', '<=')
        texto = texto.replace('▶️', '>')
        texto = texto.replace('◀️', '<')
        texto = texto.replace('⏯️', '==')
        texto = texto.replace('🔀', '!=')
        texto = texto.replace('🔄', 'for')
        texto = texto.replace('➕', '+')
        texto = texto.replace('➖', '-')
        texto = texto.replace('✖️', '*')
        texto = texto.replace('➗', '/')
        texto = texto.replace('⬆️', '**')
        texto = texto.replace('✅', 'True')
        texto = texto.replace('❌', 'False')
        texto = texto.replace('❓', 'if')
        texto = texto.replace('💡', 'else')
        texto = texto.replace('⚙️', 'def')
        texto = texto.replace('📥', 'input')
        texto = texto.replace('🔢', 'int')
        texto = texto.replace('🔡', 'str')
        texto = texto.replace('🔣', 'bool')
        texto = texto.replace('#️⃣', 'float')
        texto = texto.replace('🆓', 'None')
        texto = texto.replace('⏩', '+=')
        texto = texto.replace('⏪', '-=')
        texto = texto.replace('👉', ',')
        #self.file.write(f"\t\t\t")
        pass
    
    # Enter a parse tree produced by rulesParser#imprimir.
    def enterImprimir(self, ctx:rulesParser.ImprimirContext):
        texto = ctx.getText()
        texto = texto.replace('🖨️', 'print')
        texto = texto.replace('⏭️', '>=')
        texto = texto.replace('⏮️', '<=')
        texto = texto.replace('▶️', '>')
        texto = texto.replace('◀️', '<')
        texto = texto.replace('⏯️', '==')
        texto = texto.replace('🔀', '!=')
        texto = texto.replace('🔄', 'or')
        texto = texto.replace('➕', '+')
        texto = texto.replace('➖', '-')
        texto = texto.replace('✖️', '*')
        texto = texto.replace('➗', '/')
        texto = texto.replace('⬆️', '**')
        texto = texto.replace('👉', ',')
        
        print(f"\t\t{texto}")
        self.file.write(f"\t\t{texto}\n")
        pass

    def enterLlamadaFuncion(self, ctx:rulesParser.LlamadaFuncionContext):
        nombre_funcion = ctx.IDENTIFICADOR().getText()
        argumentos = ctx.argumentos().getText() if ctx.argumentos() else ""
        llamada = f"{nombre_funcion}({argumentos})"
        self.llamadas_funciones.append(llamada)
        pass


