# Generated from rules.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,41,214,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,1,0,1,0,1,0,1,0,1,1,
        1,1,1,1,1,1,1,1,1,1,1,1,5,1,62,8,1,10,1,12,1,65,9,1,1,2,1,2,1,2,
        1,2,1,2,1,3,1,3,1,3,1,3,1,3,1,3,1,3,3,3,79,8,3,1,4,1,4,1,4,1,4,1,
        4,1,4,1,4,1,4,5,4,89,8,4,10,4,12,4,92,9,4,1,4,1,4,1,5,1,5,1,5,1,
        5,1,5,1,5,1,5,1,5,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,5,6,112,8,6,10,
        6,12,6,115,9,6,1,6,1,6,1,7,1,7,1,7,1,7,3,7,123,8,7,1,7,1,7,1,7,1,
        8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,5,8,136,8,8,10,8,12,8,139,9,8,1,8,
        1,8,1,9,1,9,1,9,3,9,146,8,9,1,9,1,9,1,10,1,10,1,10,1,10,1,10,1,11,
        1,11,1,11,1,11,1,11,1,11,1,11,1,12,1,12,1,12,5,12,165,8,12,10,12,
        12,12,168,9,12,1,13,1,13,1,13,5,13,173,8,13,10,13,12,13,176,9,13,
        1,14,1,14,1,14,1,14,1,15,1,15,1,15,1,15,1,16,1,16,1,16,1,16,5,16,
        190,8,16,10,16,12,16,193,9,16,1,17,1,17,1,18,1,18,1,19,1,19,1,19,
        1,19,1,20,1,20,1,20,1,21,1,21,1,22,1,22,1,23,1,23,1,24,1,24,1,24,
        0,0,25,0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,32,34,36,38,40,
        42,44,46,48,0,5,2,0,10,11,37,39,1,0,12,16,1,0,17,18,2,0,7,7,19,23,
        1,0,24,30,222,0,50,1,0,0,0,2,63,1,0,0,0,4,66,1,0,0,0,6,71,1,0,0,
        0,8,80,1,0,0,0,10,95,1,0,0,0,12,103,1,0,0,0,14,118,1,0,0,0,16,127,
        1,0,0,0,18,142,1,0,0,0,20,149,1,0,0,0,22,154,1,0,0,0,24,161,1,0,
        0,0,26,169,1,0,0,0,28,177,1,0,0,0,30,181,1,0,0,0,32,185,1,0,0,0,
        34,194,1,0,0,0,36,196,1,0,0,0,38,198,1,0,0,0,40,202,1,0,0,0,42,205,
        1,0,0,0,44,207,1,0,0,0,46,209,1,0,0,0,48,211,1,0,0,0,50,51,3,46,
        23,0,51,52,3,2,1,0,52,53,3,48,24,0,53,1,1,0,0,0,54,62,3,4,2,0,55,
        62,3,6,3,0,56,62,3,10,5,0,57,62,3,14,7,0,58,62,3,18,9,0,59,62,3,
        20,10,0,60,62,3,22,11,0,61,54,1,0,0,0,61,55,1,0,0,0,61,56,1,0,0,
        0,61,57,1,0,0,0,61,58,1,0,0,0,61,59,1,0,0,0,61,60,1,0,0,0,62,65,
        1,0,0,0,63,61,1,0,0,0,63,64,1,0,0,0,64,3,1,0,0,0,65,63,1,0,0,0,66,
        67,3,36,18,0,67,68,5,37,0,0,68,69,5,1,0,0,69,70,3,32,16,0,70,5,1,
        0,0,0,71,72,5,33,0,0,72,73,5,2,0,0,73,74,3,28,14,0,74,75,5,3,0,0,
        75,78,3,8,4,0,76,77,5,4,0,0,77,79,3,8,4,0,78,76,1,0,0,0,78,79,1,
        0,0,0,79,7,1,0,0,0,80,90,5,5,0,0,81,89,3,4,2,0,82,89,3,6,3,0,83,
        89,3,10,5,0,84,89,3,14,7,0,85,89,3,18,9,0,86,89,3,20,10,0,87,89,
        3,22,11,0,88,81,1,0,0,0,88,82,1,0,0,0,88,83,1,0,0,0,88,84,1,0,0,
        0,88,85,1,0,0,0,88,86,1,0,0,0,88,87,1,0,0,0,89,92,1,0,0,0,90,88,
        1,0,0,0,90,91,1,0,0,0,91,93,1,0,0,0,92,90,1,0,0,0,93,94,5,6,0,0,
        94,9,1,0,0,0,95,96,5,36,0,0,96,97,5,2,0,0,97,98,3,38,19,0,98,99,
        5,7,0,0,99,100,3,28,14,0,100,101,5,3,0,0,101,102,3,12,6,0,102,11,
        1,0,0,0,103,113,5,5,0,0,104,112,3,4,2,0,105,112,3,6,3,0,106,112,
        3,10,5,0,107,112,3,14,7,0,108,112,3,18,9,0,109,112,3,20,10,0,110,
        112,3,22,11,0,111,104,1,0,0,0,111,105,1,0,0,0,111,106,1,0,0,0,111,
        107,1,0,0,0,111,108,1,0,0,0,111,109,1,0,0,0,111,110,1,0,0,0,112,
        115,1,0,0,0,113,111,1,0,0,0,113,114,1,0,0,0,114,116,1,0,0,0,115,
        113,1,0,0,0,116,117,5,6,0,0,117,13,1,0,0,0,118,119,5,8,0,0,119,120,
        5,37,0,0,120,122,5,2,0,0,121,123,3,24,12,0,122,121,1,0,0,0,122,123,
        1,0,0,0,123,124,1,0,0,0,124,125,5,3,0,0,125,126,3,16,8,0,126,15,
        1,0,0,0,127,137,5,5,0,0,128,136,3,4,2,0,129,136,3,6,3,0,130,136,
        3,10,5,0,131,136,3,14,7,0,132,136,3,18,9,0,133,136,3,20,10,0,134,
        136,3,22,11,0,135,128,1,0,0,0,135,129,1,0,0,0,135,130,1,0,0,0,135,
        131,1,0,0,0,135,132,1,0,0,0,135,133,1,0,0,0,135,134,1,0,0,0,136,
        139,1,0,0,0,137,135,1,0,0,0,137,138,1,0,0,0,138,140,1,0,0,0,139,
        137,1,0,0,0,140,141,5,6,0,0,141,17,1,0,0,0,142,143,5,37,0,0,143,
        145,5,2,0,0,144,146,3,26,13,0,145,144,1,0,0,0,145,146,1,0,0,0,146,
        147,1,0,0,0,147,148,5,3,0,0,148,19,1,0,0,0,149,150,5,34,0,0,150,
        151,5,2,0,0,151,152,3,32,16,0,152,153,5,3,0,0,153,21,1,0,0,0,154,
        155,5,37,0,0,155,156,5,1,0,0,156,157,5,35,0,0,157,158,5,2,0,0,158,
        159,5,39,0,0,159,160,5,3,0,0,160,23,1,0,0,0,161,166,5,37,0,0,162,
        163,5,9,0,0,163,165,5,37,0,0,164,162,1,0,0,0,165,168,1,0,0,0,166,
        164,1,0,0,0,166,167,1,0,0,0,167,25,1,0,0,0,168,166,1,0,0,0,169,174,
        3,32,16,0,170,171,5,9,0,0,171,173,3,32,16,0,172,170,1,0,0,0,173,
        176,1,0,0,0,174,172,1,0,0,0,174,175,1,0,0,0,175,27,1,0,0,0,176,174,
        1,0,0,0,177,178,3,32,16,0,178,179,3,44,22,0,179,180,3,32,16,0,180,
        29,1,0,0,0,181,182,5,5,0,0,182,183,3,2,1,0,183,184,5,6,0,0,184,31,
        1,0,0,0,185,191,3,34,17,0,186,187,3,42,21,0,187,188,3,34,17,0,188,
        190,1,0,0,0,189,186,1,0,0,0,190,193,1,0,0,0,191,189,1,0,0,0,191,
        192,1,0,0,0,192,33,1,0,0,0,193,191,1,0,0,0,194,195,7,0,0,0,195,35,
        1,0,0,0,196,197,7,1,0,0,197,37,1,0,0,0,198,199,5,37,0,0,199,200,
        5,1,0,0,200,201,3,32,16,0,201,39,1,0,0,0,202,203,5,37,0,0,203,204,
        7,2,0,0,204,41,1,0,0,0,205,206,7,3,0,0,206,43,1,0,0,0,207,208,7,
        4,0,0,208,45,1,0,0,0,209,210,5,31,0,0,210,47,1,0,0,0,211,212,5,32,
        0,0,212,49,1,0,0,0,14,61,63,78,88,90,111,113,122,135,137,145,166,
        174,191
    ]

class rulesParser ( Parser ):

    grammarFileName = "rules.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'='", "'('", "')'", "'\\U0001F4A1'", 
                     "'{'", "'}'", "'\\U0001F449'", "'\\u2699\\uFE0F'", 
                     "','", "'\\u2705'", "'\\u274C'", "'\\U0001F522'", "'\\U0001F521'", 
                     "'\\U0001F523'", "'#\\uFE0F\\u20E3'", "'\\U0001F193'", 
                     "'\\u23E9'", "'\\u23EA'", "'\\u2795'", "'\\u2796'", 
                     "'\\u2716\\uFE0F'", "'\\u2797'", "'\\u2B06\\uFE0F'", 
                     "'\\u25B6\\uFE0F'", "'\\u25C0\\uFE0F'", "'\\u23ED\\uFE0F'", 
                     "'\\u23EE\\uFE0F'", "'\\u23EF\\uFE0F'", "'\\U0001F500'", 
                     "'\\u23F9\\uFE0F'", "'\\U0001F6A9'", "'\\U0001F6D1'", 
                     "'\\u2753'", "'\\U0001F5A8\\uFE0F'", "'\\U0001F4E5'", 
                     "'\\U0001F504'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "IF", "PRINT", "INPUT", "FOR", "IDENTIFICADOR", 
                      "NUMERO", "STRING", "COMENTARIO", "ESPACIOS" ]

    RULE_programa = 0
    RULE_bloquePrograma = 1
    RULE_declaracion = 2
    RULE_condicion = 3
    RULE_bloqueCondicion = 4
    RULE_ciclo = 5
    RULE_bloqueCiclo = 6
    RULE_funcion = 7
    RULE_bloqueFuncion = 8
    RULE_llamadaFuncion = 9
    RULE_imprimir = 10
    RULE_entrada = 11
    RULE_parametros = 12
    RULE_argumentos = 13
    RULE_condicionLogica = 14
    RULE_bloque = 15
    RULE_expresion = 16
    RULE_termino = 17
    RULE_tipoDato = 18
    RULE_asignacion = 19
    RULE_incremento = 20
    RULE_operadorAritmetico = 21
    RULE_operadorLogico = 22
    RULE_inicio = 23
    RULE_fin = 24

    ruleNames =  [ "programa", "bloquePrograma", "declaracion", "condicion", 
                   "bloqueCondicion", "ciclo", "bloqueCiclo", "funcion", 
                   "bloqueFuncion", "llamadaFuncion", "imprimir", "entrada", 
                   "parametros", "argumentos", "condicionLogica", "bloque", 
                   "expresion", "termino", "tipoDato", "asignacion", "incremento", 
                   "operadorAritmetico", "operadorLogico", "inicio", "fin" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    T__11=12
    T__12=13
    T__13=14
    T__14=15
    T__15=16
    T__16=17
    T__17=18
    T__18=19
    T__19=20
    T__20=21
    T__21=22
    T__22=23
    T__23=24
    T__24=25
    T__25=26
    T__26=27
    T__27=28
    T__28=29
    T__29=30
    T__30=31
    T__31=32
    IF=33
    PRINT=34
    INPUT=35
    FOR=36
    IDENTIFICADOR=37
    NUMERO=38
    STRING=39
    COMENTARIO=40
    ESPACIOS=41

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgramaContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def inicio(self):
            return self.getTypedRuleContext(rulesParser.InicioContext,0)


        def bloquePrograma(self):
            return self.getTypedRuleContext(rulesParser.BloqueProgramaContext,0)


        def fin(self):
            return self.getTypedRuleContext(rulesParser.FinContext,0)


        def getRuleIndex(self):
            return rulesParser.RULE_programa

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrograma" ):
                listener.enterPrograma(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrograma" ):
                listener.exitPrograma(self)




    def programa(self):

        localctx = rulesParser.ProgramaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_programa)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 50
            self.inicio()
            self.state = 51
            self.bloquePrograma()
            self.state = 52
            self.fin()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BloqueProgramaContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def declaracion(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(rulesParser.DeclaracionContext)
            else:
                return self.getTypedRuleContext(rulesParser.DeclaracionContext,i)


        def condicion(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(rulesParser.CondicionContext)
            else:
                return self.getTypedRuleContext(rulesParser.CondicionContext,i)


        def ciclo(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(rulesParser.CicloContext)
            else:
                return self.getTypedRuleContext(rulesParser.CicloContext,i)


        def funcion(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(rulesParser.FuncionContext)
            else:
                return self.getTypedRuleContext(rulesParser.FuncionContext,i)


        def llamadaFuncion(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(rulesParser.LlamadaFuncionContext)
            else:
                return self.getTypedRuleContext(rulesParser.LlamadaFuncionContext,i)


        def imprimir(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(rulesParser.ImprimirContext)
            else:
                return self.getTypedRuleContext(rulesParser.ImprimirContext,i)


        def entrada(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(rulesParser.EntradaContext)
            else:
                return self.getTypedRuleContext(rulesParser.EntradaContext,i)


        def getRuleIndex(self):
            return rulesParser.RULE_bloquePrograma

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBloquePrograma" ):
                listener.enterBloquePrograma(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBloquePrograma" ):
                listener.exitBloquePrograma(self)




    def bloquePrograma(self):

        localctx = rulesParser.BloqueProgramaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_bloquePrograma)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 63
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 231928361216) != 0):
                self.state = 61
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,0,self._ctx)
                if la_ == 1:
                    self.state = 54
                    self.declaracion()
                    pass

                elif la_ == 2:
                    self.state = 55
                    self.condicion()
                    pass

                elif la_ == 3:
                    self.state = 56
                    self.ciclo()
                    pass

                elif la_ == 4:
                    self.state = 57
                    self.funcion()
                    pass

                elif la_ == 5:
                    self.state = 58
                    self.llamadaFuncion()
                    pass

                elif la_ == 6:
                    self.state = 59
                    self.imprimir()
                    pass

                elif la_ == 7:
                    self.state = 60
                    self.entrada()
                    pass


                self.state = 65
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DeclaracionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def tipoDato(self):
            return self.getTypedRuleContext(rulesParser.TipoDatoContext,0)


        def IDENTIFICADOR(self):
            return self.getToken(rulesParser.IDENTIFICADOR, 0)

        def expresion(self):
            return self.getTypedRuleContext(rulesParser.ExpresionContext,0)


        def getRuleIndex(self):
            return rulesParser.RULE_declaracion

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDeclaracion" ):
                listener.enterDeclaracion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDeclaracion" ):
                listener.exitDeclaracion(self)




    def declaracion(self):

        localctx = rulesParser.DeclaracionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_declaracion)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 66
            self.tipoDato()
            self.state = 67
            self.match(rulesParser.IDENTIFICADOR)
            self.state = 68
            self.match(rulesParser.T__0)
            self.state = 69
            self.expresion()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CondicionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IF(self):
            return self.getToken(rulesParser.IF, 0)

        def condicionLogica(self):
            return self.getTypedRuleContext(rulesParser.CondicionLogicaContext,0)


        def bloqueCondicion(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(rulesParser.BloqueCondicionContext)
            else:
                return self.getTypedRuleContext(rulesParser.BloqueCondicionContext,i)


        def getRuleIndex(self):
            return rulesParser.RULE_condicion

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCondicion" ):
                listener.enterCondicion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCondicion" ):
                listener.exitCondicion(self)




    def condicion(self):

        localctx = rulesParser.CondicionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_condicion)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 71
            self.match(rulesParser.IF)
            self.state = 72
            self.match(rulesParser.T__1)
            self.state = 73
            self.condicionLogica()
            self.state = 74
            self.match(rulesParser.T__2)
            self.state = 75
            self.bloqueCondicion()
            self.state = 78
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==4:
                self.state = 76
                self.match(rulesParser.T__3)
                self.state = 77
                self.bloqueCondicion()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BloqueCondicionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def declaracion(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(rulesParser.DeclaracionContext)
            else:
                return self.getTypedRuleContext(rulesParser.DeclaracionContext,i)


        def condicion(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(rulesParser.CondicionContext)
            else:
                return self.getTypedRuleContext(rulesParser.CondicionContext,i)


        def ciclo(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(rulesParser.CicloContext)
            else:
                return self.getTypedRuleContext(rulesParser.CicloContext,i)


        def funcion(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(rulesParser.FuncionContext)
            else:
                return self.getTypedRuleContext(rulesParser.FuncionContext,i)


        def llamadaFuncion(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(rulesParser.LlamadaFuncionContext)
            else:
                return self.getTypedRuleContext(rulesParser.LlamadaFuncionContext,i)


        def imprimir(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(rulesParser.ImprimirContext)
            else:
                return self.getTypedRuleContext(rulesParser.ImprimirContext,i)


        def entrada(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(rulesParser.EntradaContext)
            else:
                return self.getTypedRuleContext(rulesParser.EntradaContext,i)


        def getRuleIndex(self):
            return rulesParser.RULE_bloqueCondicion

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBloqueCondicion" ):
                listener.enterBloqueCondicion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBloqueCondicion" ):
                listener.exitBloqueCondicion(self)




    def bloqueCondicion(self):

        localctx = rulesParser.BloqueCondicionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_bloqueCondicion)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 80
            self.match(rulesParser.T__4)
            self.state = 90
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 231928361216) != 0):
                self.state = 88
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,3,self._ctx)
                if la_ == 1:
                    self.state = 81
                    self.declaracion()
                    pass

                elif la_ == 2:
                    self.state = 82
                    self.condicion()
                    pass

                elif la_ == 3:
                    self.state = 83
                    self.ciclo()
                    pass

                elif la_ == 4:
                    self.state = 84
                    self.funcion()
                    pass

                elif la_ == 5:
                    self.state = 85
                    self.llamadaFuncion()
                    pass

                elif la_ == 6:
                    self.state = 86
                    self.imprimir()
                    pass

                elif la_ == 7:
                    self.state = 87
                    self.entrada()
                    pass


                self.state = 92
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 93
            self.match(rulesParser.T__5)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CicloContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def FOR(self):
            return self.getToken(rulesParser.FOR, 0)

        def asignacion(self):
            return self.getTypedRuleContext(rulesParser.AsignacionContext,0)


        def condicionLogica(self):
            return self.getTypedRuleContext(rulesParser.CondicionLogicaContext,0)


        def bloqueCiclo(self):
            return self.getTypedRuleContext(rulesParser.BloqueCicloContext,0)


        def getRuleIndex(self):
            return rulesParser.RULE_ciclo

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCiclo" ):
                listener.enterCiclo(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCiclo" ):
                listener.exitCiclo(self)




    def ciclo(self):

        localctx = rulesParser.CicloContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_ciclo)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 95
            self.match(rulesParser.FOR)
            self.state = 96
            self.match(rulesParser.T__1)
            self.state = 97
            self.asignacion()
            self.state = 98
            self.match(rulesParser.T__6)
            self.state = 99
            self.condicionLogica()
            self.state = 100
            self.match(rulesParser.T__2)
            self.state = 101
            self.bloqueCiclo()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BloqueCicloContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def declaracion(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(rulesParser.DeclaracionContext)
            else:
                return self.getTypedRuleContext(rulesParser.DeclaracionContext,i)


        def condicion(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(rulesParser.CondicionContext)
            else:
                return self.getTypedRuleContext(rulesParser.CondicionContext,i)


        def ciclo(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(rulesParser.CicloContext)
            else:
                return self.getTypedRuleContext(rulesParser.CicloContext,i)


        def funcion(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(rulesParser.FuncionContext)
            else:
                return self.getTypedRuleContext(rulesParser.FuncionContext,i)


        def llamadaFuncion(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(rulesParser.LlamadaFuncionContext)
            else:
                return self.getTypedRuleContext(rulesParser.LlamadaFuncionContext,i)


        def imprimir(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(rulesParser.ImprimirContext)
            else:
                return self.getTypedRuleContext(rulesParser.ImprimirContext,i)


        def entrada(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(rulesParser.EntradaContext)
            else:
                return self.getTypedRuleContext(rulesParser.EntradaContext,i)


        def getRuleIndex(self):
            return rulesParser.RULE_bloqueCiclo

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBloqueCiclo" ):
                listener.enterBloqueCiclo(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBloqueCiclo" ):
                listener.exitBloqueCiclo(self)




    def bloqueCiclo(self):

        localctx = rulesParser.BloqueCicloContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_bloqueCiclo)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 103
            self.match(rulesParser.T__4)
            self.state = 113
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 231928361216) != 0):
                self.state = 111
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,5,self._ctx)
                if la_ == 1:
                    self.state = 104
                    self.declaracion()
                    pass

                elif la_ == 2:
                    self.state = 105
                    self.condicion()
                    pass

                elif la_ == 3:
                    self.state = 106
                    self.ciclo()
                    pass

                elif la_ == 4:
                    self.state = 107
                    self.funcion()
                    pass

                elif la_ == 5:
                    self.state = 108
                    self.llamadaFuncion()
                    pass

                elif la_ == 6:
                    self.state = 109
                    self.imprimir()
                    pass

                elif la_ == 7:
                    self.state = 110
                    self.entrada()
                    pass


                self.state = 115
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 116
            self.match(rulesParser.T__5)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FuncionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFICADOR(self):
            return self.getToken(rulesParser.IDENTIFICADOR, 0)

        def bloqueFuncion(self):
            return self.getTypedRuleContext(rulesParser.BloqueFuncionContext,0)


        def parametros(self):
            return self.getTypedRuleContext(rulesParser.ParametrosContext,0)


        def getRuleIndex(self):
            return rulesParser.RULE_funcion

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFuncion" ):
                listener.enterFuncion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFuncion" ):
                listener.exitFuncion(self)




    def funcion(self):

        localctx = rulesParser.FuncionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_funcion)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 118
            self.match(rulesParser.T__7)
            self.state = 119
            self.match(rulesParser.IDENTIFICADOR)
            self.state = 120
            self.match(rulesParser.T__1)
            self.state = 122
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==37:
                self.state = 121
                self.parametros()


            self.state = 124
            self.match(rulesParser.T__2)
            self.state = 125
            self.bloqueFuncion()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BloqueFuncionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def declaracion(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(rulesParser.DeclaracionContext)
            else:
                return self.getTypedRuleContext(rulesParser.DeclaracionContext,i)


        def condicion(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(rulesParser.CondicionContext)
            else:
                return self.getTypedRuleContext(rulesParser.CondicionContext,i)


        def ciclo(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(rulesParser.CicloContext)
            else:
                return self.getTypedRuleContext(rulesParser.CicloContext,i)


        def funcion(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(rulesParser.FuncionContext)
            else:
                return self.getTypedRuleContext(rulesParser.FuncionContext,i)


        def llamadaFuncion(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(rulesParser.LlamadaFuncionContext)
            else:
                return self.getTypedRuleContext(rulesParser.LlamadaFuncionContext,i)


        def imprimir(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(rulesParser.ImprimirContext)
            else:
                return self.getTypedRuleContext(rulesParser.ImprimirContext,i)


        def entrada(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(rulesParser.EntradaContext)
            else:
                return self.getTypedRuleContext(rulesParser.EntradaContext,i)


        def getRuleIndex(self):
            return rulesParser.RULE_bloqueFuncion

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBloqueFuncion" ):
                listener.enterBloqueFuncion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBloqueFuncion" ):
                listener.exitBloqueFuncion(self)




    def bloqueFuncion(self):

        localctx = rulesParser.BloqueFuncionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_bloqueFuncion)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 127
            self.match(rulesParser.T__4)
            self.state = 137
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 231928361216) != 0):
                self.state = 135
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,8,self._ctx)
                if la_ == 1:
                    self.state = 128
                    self.declaracion()
                    pass

                elif la_ == 2:
                    self.state = 129
                    self.condicion()
                    pass

                elif la_ == 3:
                    self.state = 130
                    self.ciclo()
                    pass

                elif la_ == 4:
                    self.state = 131
                    self.funcion()
                    pass

                elif la_ == 5:
                    self.state = 132
                    self.llamadaFuncion()
                    pass

                elif la_ == 6:
                    self.state = 133
                    self.imprimir()
                    pass

                elif la_ == 7:
                    self.state = 134
                    self.entrada()
                    pass


                self.state = 139
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 140
            self.match(rulesParser.T__5)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LlamadaFuncionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFICADOR(self):
            return self.getToken(rulesParser.IDENTIFICADOR, 0)

        def argumentos(self):
            return self.getTypedRuleContext(rulesParser.ArgumentosContext,0)


        def getRuleIndex(self):
            return rulesParser.RULE_llamadaFuncion

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLlamadaFuncion" ):
                listener.enterLlamadaFuncion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLlamadaFuncion" ):
                listener.exitLlamadaFuncion(self)




    def llamadaFuncion(self):

        localctx = rulesParser.LlamadaFuncionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_llamadaFuncion)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 142
            self.match(rulesParser.IDENTIFICADOR)
            self.state = 143
            self.match(rulesParser.T__1)
            self.state = 145
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 962072677376) != 0):
                self.state = 144
                self.argumentos()


            self.state = 147
            self.match(rulesParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ImprimirContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def PRINT(self):
            return self.getToken(rulesParser.PRINT, 0)

        def expresion(self):
            return self.getTypedRuleContext(rulesParser.ExpresionContext,0)


        def getRuleIndex(self):
            return rulesParser.RULE_imprimir

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterImprimir" ):
                listener.enterImprimir(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitImprimir" ):
                listener.exitImprimir(self)




    def imprimir(self):

        localctx = rulesParser.ImprimirContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_imprimir)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 149
            self.match(rulesParser.PRINT)
            self.state = 150
            self.match(rulesParser.T__1)
            self.state = 151
            self.expresion()
            self.state = 152
            self.match(rulesParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EntradaContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFICADOR(self):
            return self.getToken(rulesParser.IDENTIFICADOR, 0)

        def INPUT(self):
            return self.getToken(rulesParser.INPUT, 0)

        def STRING(self):
            return self.getToken(rulesParser.STRING, 0)

        def getRuleIndex(self):
            return rulesParser.RULE_entrada

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEntrada" ):
                listener.enterEntrada(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEntrada" ):
                listener.exitEntrada(self)




    def entrada(self):

        localctx = rulesParser.EntradaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_entrada)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 154
            self.match(rulesParser.IDENTIFICADOR)
            self.state = 155
            self.match(rulesParser.T__0)
            self.state = 156
            self.match(rulesParser.INPUT)
            self.state = 157
            self.match(rulesParser.T__1)
            self.state = 158
            self.match(rulesParser.STRING)
            self.state = 159
            self.match(rulesParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParametrosContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFICADOR(self, i:int=None):
            if i is None:
                return self.getTokens(rulesParser.IDENTIFICADOR)
            else:
                return self.getToken(rulesParser.IDENTIFICADOR, i)

        def getRuleIndex(self):
            return rulesParser.RULE_parametros

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParametros" ):
                listener.enterParametros(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParametros" ):
                listener.exitParametros(self)




    def parametros(self):

        localctx = rulesParser.ParametrosContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_parametros)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 161
            self.match(rulesParser.IDENTIFICADOR)
            self.state = 166
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==9:
                self.state = 162
                self.match(rulesParser.T__8)
                self.state = 163
                self.match(rulesParser.IDENTIFICADOR)
                self.state = 168
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ArgumentosContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expresion(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(rulesParser.ExpresionContext)
            else:
                return self.getTypedRuleContext(rulesParser.ExpresionContext,i)


        def getRuleIndex(self):
            return rulesParser.RULE_argumentos

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArgumentos" ):
                listener.enterArgumentos(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArgumentos" ):
                listener.exitArgumentos(self)




    def argumentos(self):

        localctx = rulesParser.ArgumentosContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_argumentos)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 169
            self.expresion()
            self.state = 174
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==9:
                self.state = 170
                self.match(rulesParser.T__8)
                self.state = 171
                self.expresion()
                self.state = 176
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CondicionLogicaContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expresion(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(rulesParser.ExpresionContext)
            else:
                return self.getTypedRuleContext(rulesParser.ExpresionContext,i)


        def operadorLogico(self):
            return self.getTypedRuleContext(rulesParser.OperadorLogicoContext,0)


        def getRuleIndex(self):
            return rulesParser.RULE_condicionLogica

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCondicionLogica" ):
                listener.enterCondicionLogica(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCondicionLogica" ):
                listener.exitCondicionLogica(self)




    def condicionLogica(self):

        localctx = rulesParser.CondicionLogicaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_condicionLogica)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 177
            self.expresion()
            self.state = 178
            self.operadorLogico()
            self.state = 179
            self.expresion()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BloqueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def bloquePrograma(self):
            return self.getTypedRuleContext(rulesParser.BloqueProgramaContext,0)


        def getRuleIndex(self):
            return rulesParser.RULE_bloque

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBloque" ):
                listener.enterBloque(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBloque" ):
                listener.exitBloque(self)




    def bloque(self):

        localctx = rulesParser.BloqueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_bloque)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 181
            self.match(rulesParser.T__4)
            self.state = 182
            self.bloquePrograma()
            self.state = 183
            self.match(rulesParser.T__5)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpresionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def termino(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(rulesParser.TerminoContext)
            else:
                return self.getTypedRuleContext(rulesParser.TerminoContext,i)


        def operadorAritmetico(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(rulesParser.OperadorAritmeticoContext)
            else:
                return self.getTypedRuleContext(rulesParser.OperadorAritmeticoContext,i)


        def getRuleIndex(self):
            return rulesParser.RULE_expresion

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpresion" ):
                listener.enterExpresion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpresion" ):
                listener.exitExpresion(self)




    def expresion(self):

        localctx = rulesParser.ExpresionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_expresion)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 185
            self.termino()
            self.state = 191
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,13,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 186
                    self.operadorAritmetico()
                    self.state = 187
                    self.termino() 
                self.state = 193
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,13,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TerminoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFICADOR(self):
            return self.getToken(rulesParser.IDENTIFICADOR, 0)

        def NUMERO(self):
            return self.getToken(rulesParser.NUMERO, 0)

        def STRING(self):
            return self.getToken(rulesParser.STRING, 0)

        def getRuleIndex(self):
            return rulesParser.RULE_termino

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTermino" ):
                listener.enterTermino(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTermino" ):
                listener.exitTermino(self)




    def termino(self):

        localctx = rulesParser.TerminoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_termino)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 194
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 962072677376) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TipoDatoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return rulesParser.RULE_tipoDato

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTipoDato" ):
                listener.enterTipoDato(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTipoDato" ):
                listener.exitTipoDato(self)




    def tipoDato(self):

        localctx = rulesParser.TipoDatoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_tipoDato)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 196
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 126976) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AsignacionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFICADOR(self):
            return self.getToken(rulesParser.IDENTIFICADOR, 0)

        def expresion(self):
            return self.getTypedRuleContext(rulesParser.ExpresionContext,0)


        def getRuleIndex(self):
            return rulesParser.RULE_asignacion

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAsignacion" ):
                listener.enterAsignacion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAsignacion" ):
                listener.exitAsignacion(self)




    def asignacion(self):

        localctx = rulesParser.AsignacionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_asignacion)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 198
            self.match(rulesParser.IDENTIFICADOR)
            self.state = 199
            self.match(rulesParser.T__0)
            self.state = 200
            self.expresion()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IncrementoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFICADOR(self):
            return self.getToken(rulesParser.IDENTIFICADOR, 0)

        def getRuleIndex(self):
            return rulesParser.RULE_incremento

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIncremento" ):
                listener.enterIncremento(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIncremento" ):
                listener.exitIncremento(self)




    def incremento(self):

        localctx = rulesParser.IncrementoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_incremento)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 202
            self.match(rulesParser.IDENTIFICADOR)
            self.state = 203
            _la = self._input.LA(1)
            if not(_la==17 or _la==18):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OperadorAritmeticoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return rulesParser.RULE_operadorAritmetico

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOperadorAritmetico" ):
                listener.enterOperadorAritmetico(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOperadorAritmetico" ):
                listener.exitOperadorAritmetico(self)




    def operadorAritmetico(self):

        localctx = rulesParser.OperadorAritmeticoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_operadorAritmetico)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 205
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 16253056) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OperadorLogicoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return rulesParser.RULE_operadorLogico

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOperadorLogico" ):
                listener.enterOperadorLogico(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOperadorLogico" ):
                listener.exitOperadorLogico(self)




    def operadorLogico(self):

        localctx = rulesParser.OperadorLogicoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_operadorLogico)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 207
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 2130706432) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InicioContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return rulesParser.RULE_inicio

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInicio" ):
                listener.enterInicio(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInicio" ):
                listener.exitInicio(self)




    def inicio(self):

        localctx = rulesParser.InicioContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_inicio)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 209
            self.match(rulesParser.T__30)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FinContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return rulesParser.RULE_fin

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFin" ):
                listener.enterFin(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFin" ):
                listener.exitFin(self)




    def fin(self):

        localctx = rulesParser.FinContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_fin)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 211
            self.match(rulesParser.T__31)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





